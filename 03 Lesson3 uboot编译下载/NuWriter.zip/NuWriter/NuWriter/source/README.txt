Please clone NuWriter source code and firmware source code from one of the following repositories.
https://github.com/OpenNuvoton/NUC970_NuWriter.git
https://git.oschina.net/OpenNuvoton/NUC970_NuWriter.git